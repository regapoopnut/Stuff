/**
 * Investment Service
 * -------------------
 * This service layer handles all business logic related to client investments.
 *
 * Responsibilities:
 *   • Process stock purchase (“buy”) requests
 *   • Mark investments as sold
 *   • Retrieve all investments for a given client
 *
 * Notes:
 *   - This service does not perform SQL directly.
 *   - All database interaction is done through the InvestmentRepository (InvRepo).
 *   - DTO transformation is not required for investments unless you add one later.
 */
const InvRepo = require('../repositories/InvestmentRepository');

async function buyStock(client_id, stock_symbol, shares) {
  return await InvRepo.create({ client_id, stock_symbol, shares });
}

async function sellStock(investment_id) {
  return await InvRepo.sell(investment_id);
}

async function getInvestmentsByClient(client_id) {
  return await InvRepo.findByClient(client_id);
}

module.exports = { buyStock, sellStock, getInvestmentsByClient };
