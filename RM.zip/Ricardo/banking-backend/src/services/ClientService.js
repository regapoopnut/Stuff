/**
 * Client Service
 * ----------------
 * This service layer contains the business logic for all operations
 * involving bank clients.
 *
 * Responsibilities:
 *   - Fetch clients (all or by ID)
 *   - Create new clients
 *   - Update existing client records
 *   - Delete clients
 *   - Transform raw database rows into DTOs before returning results
 *
 * Notes:
 *   - Services NEVER run SQL directly; that is handled by repositories.
 *   - Services ensure clean API-ready data by applying DTO transforms.
 */
const ClientRepo = require('../repositories/ClientRepository');
const { toClientDTO } = require('../domain/dto/ClientDTO');

async function getClients() {
  const rows = await ClientRepo.findAll();
  return rows.map(toClientDTO);
}
async function getClientById(id) {
  const row = await ClientRepo.findById(id);
  return toClientDTO(row);
}
async function addClient(dto) {
  const row = await ClientRepo.create(dto);
  return toClientDTO(row);
}
async function updateClient(id, dto) {
  const row = await ClientRepo.update(id, dto);
  return toClientDTO(row);
}
async function deleteClient(id) {
  await ClientRepo.remove(id);
  return true;
}

module.exports = { getClients, getClientById, addClient, updateClient, deleteClient };
