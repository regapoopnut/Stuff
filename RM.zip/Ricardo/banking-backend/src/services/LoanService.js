/**
 * Loan Service
 * -------------
 * Handles business logic for processing client loans.
 *
 * Responsibilities:
 *   • Apply for a new loan
 *   • Approve or reject pending loans
 *   • Mark a loan as fully paid
 *   • Retrieve all loans belonging to a specific client
 *
 * Notes:
 *   - All SQL operations are delegated to LoanRepository (LoanRepo)
 *   - This service only coordinates workflow and enforces business rules
 */
const LoanRepo = require('../repositories/LoanRepository');

async function applyLoan(client_id, amount, interest_rate, employee_id) {
  return await LoanRepo.create({ client_id, amount, interest_rate, employee_id });
}

async function approveLoan(loan_id, employee_id) {
  return await LoanRepo.updateStatus(loan_id, 'approved', employee_id);
}

async function rejectLoan(loan_id, employee_id) {
  return await LoanRepo.updateStatus(loan_id, 'rejected', employee_id);
}

async function markLoanPaid(loan_id) {
  return await LoanRepo.updateStatus(loan_id, 'paid', null);
}

async function getLoansByClient(client_id) {
  return await LoanRepo.findByClient(client_id);
}

module.exports = { applyLoan, approveLoan, rejectLoan, markLoanPaid, getLoansByClient };
