/**
 * Employee Service
 * -----------------
 * Business logic for managing employees within the banking system.
 *
 * Responsibilities:
 *   • Retrieve employee information
 *   • Create, update, and delete employees
 *   • Handle secure authentication (login)
 *   • Hash passwords before saving to the database
 *   • Generate JWT tokens for authenticated sessions
 *
 * Notes:
 *   - This service layer never interacts with SQL directly. All DB operations
 *     are delegated to the EmployeeRepository.
 *   - Sensitive fields (password_hash) are NEVER returned to the client,
 *     thanks to DTO transformation.
 */
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const EmployeeRepo = require('../repositories/EmployeeRepository');
const { toEmployeeDTO } = require('../domain/dto/EmployeeDTO');

async function getEmployees() {
  const rows = await EmployeeRepo.findAll();
  return rows.map(toEmployeeDTO);
}

async function getEmployeeById(id) {
  const row = await EmployeeRepo.findById(id);
  return toEmployeeDTO(row);
}

async function createEmployee({ full_name, branch, role, email, password }) {
  const existing = await EmployeeRepo.findByEmail(email);
  if (existing) {
    const err = new Error('Email already registered');
    err.status = 400;
    throw err;
  }
  const password_hash = await bcrypt.hash(password, 10);
  const row = await EmployeeRepo.create({ full_name, branch, role, email, password_hash });
  return toEmployeeDTO(row);
}

async function updateEmployee(id, { full_name, branch, role, email, password }) {
  const password_hash = password ? await bcrypt.hash(password, 10) : null;
  const row = await EmployeeRepo.update(id, { full_name, branch, role, email, password_hash });
  return toEmployeeDTO(row);
}

async function deleteEmployee(id) {
  await EmployeeRepo.remove(id);
  return true;
}

async function login(email, password) {
  const row = await EmployeeRepo.findByEmail(email);
  if (!row) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    throw err;
  }
  const match = await bcrypt.compare(password, row.password_hash);
  if (!match) {
    const err = new Error('Invalid credentials');
    err.status = 401;
    throw err;
  }
  const token = jwt.sign(
    { employee_id: row.employee_id, role: row.role, email: row.email, name: row.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '2h' }
  );
  return { token, employee: toEmployeeDTO(row) };
}

module.exports = { getEmployees, getEmployeeById, createEmployee, updateEmployee, deleteEmployee, login };
