/**
 * Transaction Service
 * --------------------
 * This service handles all *money-movement* logic in the banking system.
 *
 * Responsibilities:
 *   • Deposit funds into an account
 *   • Withdraw funds safely (with insufficient balance checks)
 *   • Transfer funds atomically between two accounts
 *   • Pay bills (treated as withdrawals)
 *   • Retrieve transaction history for an account
 *
 * Notes:
 *   - Actual balance calculations and database locking logic are implemented
 *     inside AccountService.adjustBalance(), which ensures:
 *       ✔ row-level locking
 *       ✔ atomic database transactions
 *       ✔ rollback on any errors
 */
const AccountRepo = require('../repositories/AccountRepository');
const { adjustBalance } = require('./AccountService');
const TransactionRepo = require('../repositories/TransactionRepository');

async function deposit(account_id, amount, employee_id) {
  const row = await adjustBalance(account_id, amount, employee_id, 'deposit');
  return row;
}

async function withdraw(account_id, amount, employee_id) {
  const row = await adjustBalance(account_id, amount, employee_id, 'withdraw');
  return row;
}

async function transfer(from_account, to_account, amount, employee_id) {
  // debit from from_account
  await adjustBalance(from_account, amount, employee_id, 'transfer_debit', to_account);
  // credit to to_account
  await adjustBalance(to_account, amount, employee_id, 'transfer_credit', from_account);
  return { from: await AccountRepo.findById(from_account), to: await AccountRepo.findById(to_account) };
}

async function payBill(account_id, amount, employee_id) {
  const row = await adjustBalance(account_id, amount, employee_id, 'bill_payment');
  return row;
}

async function getTransactionsByAccount(account_id) {
  const rows = await TransactionRepo.findByAccount(account_id);
  return rows;
}

module.exports = { deposit, withdraw, transfer, payBill, getTransactionsByAccount };
