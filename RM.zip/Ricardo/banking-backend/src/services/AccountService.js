/**
 * Account Service
 * ----------------
 * Handles all business logic related to bank accounts.
 *
 * Responsibilities:
 *   • Fetch accounts (by client or by id)
 *   • Create new accounts
 *   • Close accounts
 *   • Adjust balances safely (deposit, withdrawal, transfer, bill payment)
 *   • Ensure operations are atomic using database transactions
 *   • Lock rows to prevent race conditions during money movement
 *
 * This layer:
 *   - Communicates with repositories for DB operations
 *   - Converts raw DB rows into DTOs for clean API responses
 *   - Contains rules and safety checks (e.g., insufficient balance)
 */
const { getClient } = require('../config/db');
const AccountRepo = require('../repositories/AccountRepository');
const TransactionRepo = require('../repositories/TransactionRepository');
const { toAccountDTO } = require('../domain/dto/AccountDTO');

async function getAccountsByClient(client_id) {
  const rows = await AccountRepo.findByClient(client_id);
  return rows.map(toAccountDTO);
}

async function getAccountById(id) {
  const row = await AccountRepo.findById(id);
  return toAccountDTO(row);
}

async function createAccount(dto) {
  const row = await AccountRepo.create(dto);
  return toAccountDTO(row);
}

async function closeAccount(account_id) {
  await AccountRepo.remove(account_id);
  return true;
}

async function adjustBalance(account_id, amount, employee_id, type, related_account=null) {
  // type: 'deposit', 'withdraw', 'transfer_credit', 'transfer_debit', 'bill_payment'
  const client = await getClient();
  try {
    await client.query('BEGIN');
    // Lock row
    const { rows: accRows } = await client.query('SELECT * FROM accounts WHERE account_id=$1 FOR UPDATE', [account_id]);
    if (!accRows[0]) {
      const err = new Error('Account not found');
      err.status = 404;
      throw err;
    }
    let balance = Number(accRows[0].balance);
    const amt = Number(amount);
    if (type in {withdraw:1, transfer_debit:1, bill_payment:1}) {
      if (balance < amt) {
        const err = new Error('Insufficient balance');
        err.status = 400;
        throw err;
      }
      balance -= amt;
    } else {
      balance += amt;
    }
    await client.query('UPDATE accounts SET balance=$1 WHERE account_id=$2', [balance, account_id]);
    await TransactionRepo.create({ account_id, employee_id, transaction_type: type, amount: amt, related_account }, client);
    await client.query('COMMIT');
    return await AccountRepo.findById(account_id);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

module.exports = { getAccountsByClient, getAccountById, createAccount, closeAccount, adjustBalance };
