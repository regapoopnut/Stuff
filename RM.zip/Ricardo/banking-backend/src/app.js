/**
 * Main Express Application Setup
 * -------------------------------
 * This file configures the Express app and all global middlewares,
 * security features, logging, routing, rate limiting, and error handling.
 *
 * Responsibilities:
 *   - Initialize Express
 *   - Apply global security middleware (helmet, CORS, rate limiting)
 *   - Parse JSON request bodies and cookies
 *   - Log requests for debugging (morgan)
 *   - Register all API route modules under /api
 *   - Provide a /health endpoint for system checks
 *   - Handle 404s and forward errors to the centralized error handler
 */
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const errorHandler = require('./middlewares/errorHandler');

const employeeRoutes = require('./routes/employeeRoutes');
const clientRoutes = require('./routes/clientRoutes');
const accountRoutes = require('./routes/accountRoutes');
const loanRoutes = require('./routes/loanRoutes');
const investmentRoutes = require('./routes/investmentRoutes');

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || '*', credentials: true }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));
app.use(express.json());
app.use(cookieParser());
app.use(morgan('dev'));

app.get('/health', (req, res) => res.json({ ok: true }));

/**
 * API Route Registration
 * -----------------------
 * All feature-specific route modules are mounted under the /api prefix.
 *
 * Example:
 *   GET /api/employees
 *   POST /api/clients
 *   GET /api/accounts/:id
 */
app.use('/api', employeeRoutes);
app.use('/api', clientRoutes);
app.use('/api', accountRoutes);
app.use('/api', loanRoutes);
app.use('/api', investmentRoutes);

// 404
app.use((req, res, next) => res.status(404).json({ error: 'Not Found' }));

// Error handler
app.use(errorHandler);

module.exports = app;
