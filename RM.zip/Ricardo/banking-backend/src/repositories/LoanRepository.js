/**
 * Loan Repository
 * ----------------
 * This module interacts directly with the `loans` table in PostgreSQL.
 *
 * Responsibilities:
 *   - Create new loan applications (status defaults to "pending")
 *   - Update the status of existing loans (approved, rejected, paid)
 *   - Fetch loans associated with a specific client
 *
 * Notes:
 *   - SQL queries use parameterized inputs to prevent SQL injection.
 *   - Repository returns raw database rows; DTO transformation is handled in the service layer.
 */
const { query } = require('../config/db');

async function create({ client_id, amount, interest_rate, employee_id }) {
  const { rows } = await query(
    `INSERT INTO loans (client_id, amount, interest_rate, employee_id, status)
     VALUES ($1,$2,$3,$4,'pending') RETURNING *`,
    [client_id, amount, interest_rate, employee_id]
  );
  return rows[0];
}

async function updateStatus(loan_id, status, employee_id=null) {
  const { rows } = await query(
    `UPDATE loans SET status=$1, employee_id=COALESCE($2, employee_id)
     WHERE loan_id=$3 RETURNING *`,
    [status, employee_id, loan_id]
  );
  return rows[0];
}

async function findByClient(client_id) {
  const { rows } = await query('SELECT * FROM loans WHERE client_id=$1 ORDER BY loan_id DESC', [client_id]);
  return rows;
}

module.exports = { create, updateStatus, findByClient };
