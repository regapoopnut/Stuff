/**
 * Investment Repository
 * ----------------------
 * Direct interface to the `investments` database table.
 *
 * Responsibilities:
 *   - Insert new investment records (stock purchases)
 *   - Update existing investments (mark as sold)
 *   - Retrieve investments per client
 *
 * Notes:
 *   - Uses parameterized SQL queries to prevent SQL injection.
 *   - Returns raw DB rows; DTO formatting is handled in the service layer.
 */
const { query } = require('../config/db');

async function create({ client_id, stock_symbol, shares }) {
  const { rows } = await query(
    `INSERT INTO investments (client_id, stock_symbol, shares, status)
     VALUES ($1,$2,$3,'active') RETURNING *`,
    [client_id, stock_symbol, shares]
  );
  return rows[0];
}

async function sell(investment_id) {
  const { rows } = await query(
    `UPDATE investments SET status='sold' WHERE investment_id=$1 RETURNING *`,
    [investment_id]
  );
  return rows[0];
}

async function findByClient(client_id) {
  const { rows } = await query(
    'SELECT * FROM investments WHERE client_id=$1 ORDER BY investment_id DESC',
    [client_id]
  );
  return rows;
}

module.exports = { create, sell, findByClient };
