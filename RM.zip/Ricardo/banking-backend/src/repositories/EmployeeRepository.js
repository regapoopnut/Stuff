/**
 * Employee Repository
 * --------------------
 * This module handles all SQL operations related to the `employees` table.
 *
 * Responsibilities:
 *   - Query employee records (all employees, by ID, by email)
 *   - Insert new employee records
 *   - Update existing employee records
 *   - Delete employees
 *
 * Notes:
 *   - All queries use parameterized SQL to prevent SQL injection.
 *   - Repository functions return *raw DB rows*; DTO formatting is handled elsewhere.
 */
const { query } = require('../config/db');

async function findAll() {
  const { rows } = await query('SELECT * FROM employees ORDER BY employee_id');
  return rows;
}

async function findById(id) {
  const { rows } = await query('SELECT * FROM employees WHERE employee_id=$1', [id]);
  return rows[0];
}

async function findByEmail(email) {
  const { rows } = await query('SELECT * FROM employees WHERE email=$1', [email]);
  return rows[0];
}

async function create({ full_name, branch, role, email, password_hash }) {
  const { rows } = await query(
    `INSERT INTO employees (full_name, branch, role, email, password_hash)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [full_name, branch, role, email, password_hash]
  );
  return rows[0];
}

async function update(id, { full_name, branch, role, email, password_hash }) {
  const { rows } = await query(
    `UPDATE employees SET full_name=$1, branch=$2, role=$3, email=$4,
     password_hash=COALESCE($5, password_hash)
     WHERE employee_id=$6 RETURNING *`,
    [full_name, branch, role, email, password_hash, id]
  );
  return rows[0];
}

async function remove(id) {
  await query('DELETE FROM employees WHERE employee_id=$1', [id]);
  return true;
}

module.exports = { findAll, findById, findByEmail, create, update, remove };
