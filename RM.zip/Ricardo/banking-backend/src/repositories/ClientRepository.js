/**
 * Client Repository
 * ------------------
 * This module communicates directly with the `clients` table in PostgreSQL.
 *
 * Responsibilities:
 *   - Runs SQL queries to fetch, insert, update, and delete client records
 *   - Returns raw database rows (DTO formatting is handled elsewhere)
 *   - Uses parameterized queries ($1, $2…) to prevent SQL injection
 *
 * CRUD Operations Supported:
 *   ✔ findAll        – retrieve all clients
 *   ✔ findById       – retrieve single client by ID
 *   ✔ create         – insert new client
 *   ✔ update         – modify existing client
 *   ✔ remove         – delete a client
 */
const { query } = require('../config/db');

async function findAll() {
  const { rows } = await query('SELECT * FROM clients ORDER BY client_id');
  return rows;
}

async function findById(id) {
  const { rows } = await query('SELECT * FROM clients WHERE client_id=$1', [id]);
  return rows[0];
}

async function create({ full_name, email, phone, address }) {
  const { rows } = await query(
    `INSERT INTO clients (full_name, email, phone, address)
     VALUES ($1,$2,$3,$4) RETURNING *`,
    [full_name, email, phone, address]
  );
  return rows[0];
}

async function update(id, { full_name, email, phone, address }) {
  const { rows } = await query(
    `UPDATE clients SET full_name=$1, email=$2, phone=$3, address=$4
     WHERE client_id=$5 RETURNING *`,
    [full_name, email, phone, address, id]
  );
  return rows[0];
}

async function remove(id) {
  await query('DELETE FROM clients WHERE client_id=$1', [id]);
  return true;
}

module.exports = { findAll, findById, create, update, remove };
