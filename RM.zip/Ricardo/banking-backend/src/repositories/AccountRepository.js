/**
 * Account Repository
 * -------------------
 * This module directly interacts with the `accounts` database table.
 *
 * Responsibilities:
 *   - Run SQL queries related to accounts
 *   - Return raw rows for the service layer to transform (DTOs)
 *   - Perform CRUD operations:
 *        ✔ find account by ID
 *        ✔ find accounts by client
 *        ✔ create new account
 *        ✔ update account balance
 *        ✔ delete account
 *
 * Notes:
 *   - All database calls use parameterized queries ($1, $2, …) to prevent SQL injection.
 *   - Repository functions NEVER format responses; that is handled by services/DTOs.
 */
const { query } = require('../config/db');

async function findById(id) {
  const { rows } = await query('SELECT * FROM accounts WHERE account_id=$1', [id]);
  return rows[0];
}

async function findByClient(client_id) {
  const { rows } = await query('SELECT * FROM accounts WHERE client_id=$1 ORDER BY account_id', [client_id]);
  return rows;
}

async function create({ client_id, account_type, balance = 0 }) {
  const { rows } = await query(
    `INSERT INTO accounts (client_id, account_type, balance)
     VALUES ($1,$2,$3) RETURNING *`,
    [client_id, account_type, balance]
  );
  return rows[0];
}

async function updateBalance(account_id, amount) {
  const { rows } = await query(
    `UPDATE accounts SET balance=$1 WHERE account_id=$2 RETURNING *`,
    [amount, account_id]
  );
  return rows[0];
}

async function remove(account_id) {
  await query('DELETE FROM accounts WHERE account_id=$1', [account_id]);
  return true;
}

module.exports = { findById, findByClient, create, updateBalance, remove };
