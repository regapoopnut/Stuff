/**
 * Transaction Repository
 * -----------------------
 * Handles all SQL operations related to the `transactions` table.
 *
 * Responsibilities:
 *   - Retrieve transactions for a specific account
 *   - Insert new transaction records (deposits, withdrawals, transfers, bill payments)
 *
 * Notes:
 *   - Uses parameterized SQL queries to prevent injection attacks.
 *   - Supports database transactions by allowing an optional client object
 *     (used when multiple queries need to commit/rollback together).
 */
const { query } = require('../config/db');

async function findByAccount(account_id) {
  const { rows } = await query(
    'SELECT * FROM transactions WHERE account_id=$1 ORDER BY transaction_id DESC',
    [account_id]
  );
  return rows;
}

async function create({ account_id, employee_id, transaction_type, amount, related_account }, client) {
  // If a transaction client is passed (inside service transaction), reuse it
  const runner = client || { query };
  const { rows } = await runner.query(
    `INSERT INTO transactions (account_id, employee_id, transaction_type, amount, related_account)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [account_id, employee_id, transaction_type, amount, related_account]
  );
  return rows[0];
}

module.exports = { findByAccount, create };
