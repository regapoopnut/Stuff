/**
 * PostgreSQL Database Connection Module
 * -------------------------------------
 * This file creates a connection pool to the PostgreSQL database using the `pg` library.
 * The pool manages multiple reusable connections, allowing the backend to efficiently
 * handle many queries at once.
 *
 * Environment variables are loaded from `.env` using `dotenv`.
 * 
 * Exports:
 *   - pool: the main PG connection pool
 *   - query: helper function for simple SQL queries
 *   - getClient: manually gets a dedicated client (usually for transactions)
 */
const { Pool } = require('pg');
require('dotenv').config();

/**
 * Create a new PostgreSQL connection pool.
 * ----------------------------------------
 * Pool options are read from environment variables, so no credentials are hardcoded.
 * - host: where PostgreSQL server runs (usually localhost)
 * - port: default is 5432
 * - user: database username
 * - password: database password
 * - database: the DB name (e.g., bankdb)
 */
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

/**
 * Global error listener for the pool.
 * -----------------------------------
 * If a connection in the pool unexpectedly errors (e.g., lost DB connection),
 * the app logs it and exits to prevent silent failures.
 */
pool.on('error', (err) => {
  console.error('Unexpected PG pool error', err);
  process.exit(-1);
});

/**
 * Helper function to run SQL queries.
 * -----------------------------------
 * Usage:
 *   query('SELECT * FROM employees WHERE id = $1', [id])
 *
 * - `text`: the SQL query string with placeholders ($1, $2, ...)
 * - `params`: array of values replacing the placeholders
 *
 * Returns:
 *   A promise resolving to the PG result object.
 */
const query = (text, params) => pool.query(text, params);
const getClient = () => pool.connect();

module.exports = { pool, query, getClient };
