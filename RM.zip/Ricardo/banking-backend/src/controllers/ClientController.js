/**
 * Client Controller
 * ------------------
 * This controller manages all HTTP endpoints related to bank clients.
 *
 * Responsibilities:
 *   - Receive requests from Express routes
 *   - Perform validation using express-validator
 *   - Forward requests to the ClientService (business logic)
 *   - Format and return responses in JSON
 *   - Pass any errors to the central error-handling middleware
 *
 * Endpoints handled:
 *   - GET /api/clients
 *   - GET /api/clients/:id
 *   - POST /api/clients
 *   - PUT /api/clients/:id
 *   - DELETE /api/clients/:id
 */
const { validationResult } = require('express-validator');
const ClientService = require('../services/ClientService');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function list(req, res, next) {
  try { res.json(await ClientService.getClients()); }
  catch (e) { next(e); }
}

async function get(req, res, next) {
  try {
    const data = await ClientService.getClientById(Number(req.params.id));
    if (!data) return res.status(404).json({ error: 'Not found' });
    res.json(data);
  } catch (e) { next(e); }
}

async function create(req, res, next) {
  try {
    handleValidation(req);
    const data = await ClientService.addClient(req.body);
    res.status(201).json(data);
  } catch (e) { next(e); }
}

async function update(req, res, next) {
  try {
    handleValidation(req);
    const data = await ClientService.updateClient(Number(req.params.id), req.body);
    res.json(data);
  } catch (e) { next(e); }
}

async function remove(req, res, next) {
  try {
    await ClientService.deleteClient(Number(req.params.id));
    res.json({ success: true });
  } catch (e) { next(e); }
}

module.exports = { list, get, create, update, remove };
