/**
 * Account Controller
 * ------------------
 * This controller handles all HTTP requests related to bank accounts.
 * It receives requests from Express routes, validates the input,
 * calls the AccountService for business logic, and returns JSON responses.
 *
 * Functions exported:
 *   - getByClient  → list all accounts for a specific client
 *   - getById      → get a single account by its ID
 *   - create       → create/open a new bank account
 *   - close        → close an existing bank account
 *
 * Validation is done using express-validator, and errors are passed
 * to Express's centralized error handler via `next()`.
 */
const { validationResult } = require('express-validator');
const AccountService = require('../services/AccountService');


function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function getByClient(req, res, next) {
  try {
    const data = await AccountService.getAccountsByClient(Number(req.params.client_id));
    res.json(data);
  } catch (e) { next(e); }
}

async function getById(req, res, next) {
  try {
    const data = await AccountService.getAccountById(Number(req.params.id));
    if (!data) return res.status(404).json({ error: 'Not found' });
    res.json(data);
  } catch (e) { next(e); }
}

async function create(req, res, next) {
  try {
    handleValidation(req);
    const data = await AccountService.createAccount(req.body);
    res.status(201).json(data);
  } catch (e) { next(e); }
}

async function close(req, res, next) {
  try {
    await AccountService.closeAccount(Number(req.params.account_id));
    res.json({ success: true });
  } catch (e) { next(e); }
}

module.exports = { getByClient, getById, create, close };
