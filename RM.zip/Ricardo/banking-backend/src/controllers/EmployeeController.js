/**
 * Employee Controller
 * --------------------
 * Handles all HTTP endpoints related to employees, including:
 *   - Employee CRUD (Admin only for create/update/delete)
 *   - Employee listing & retrieval (Manager/Admin)
 *   - Login (all users)
 *
 * This controller:
 *   - Performs input validation (express-validator)
 *   - Sends requests to the EmployeeService (business logic)
 *   - Returns consistent JSON responses
 *   - Passes errors to the global error handling middleware
 */
const { validationResult } = require('express-validator');
const EmployeeService = require('../services/EmployeeService');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function list(req, res, next) {
  try {
    const data = await EmployeeService.getEmployees();
    res.json(data);
  } catch (e) { next(e); }
}

async function get(req, res, next) {
  try {
    const data = await EmployeeService.getEmployeeById(Number(req.params.id));
    if (!data) return res.status(404).json({ error: 'Not found' });
    res.json(data);
  } catch (e) { next(e); }
}

async function create(req, res, next) {
  try {
    handleValidation(req);
    const data = await EmployeeService.createEmployee(req.body);
    res.status(201).json(data);
  } catch (e) { next(e); }
}

async function update(req, res, next) {
  try {
    handleValidation(req);
    const data = await EmployeeService.updateEmployee(Number(req.params.id), req.body);
    res.json(data);
  } catch (e) { next(e); }
}

async function remove(req, res, next) {
  try {
    await EmployeeService.deleteEmployee(Number(req.params.id));
    res.json({ success: true });
  } catch (e) { next(e); }
}

async function login(req, res, next) {
  try {
    handleValidation(req);
    const result = await EmployeeService.login(req.body.email, req.body.password);
    res.json(result);
  } catch (e) { next(e); }
}

module.exports = { list, get, create, update, remove, login };
