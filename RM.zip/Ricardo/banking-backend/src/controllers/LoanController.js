/**
 * Loan Controller
 * ----------------
 * Handles all HTTP endpoints related to loan processing.
 *
 * Supported Operations:
 *   - Apply for a new loan (any teller/manager/admin)
 *   - Approve a pending loan (manager/admin only)
 *   - Reject a pending loan (manager/admin only)
 *   - Mark an approved loan as paid (manager/admin only)
 *   - List all loans for a specific client
 *
 * Responsibilities:
 *   - Validate incoming request fields (express-validator)
 *   - Pass business logic operations to the LoanService
 *   - Return structured JSON responses
 *   - Forward exceptions to the central error middleware via next()
 */

const { validationResult } = require('express-validator');
const LoanService = require('../services/LoanService');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function apply(req, res, next) {
  try { handleValidation(req);
    const row = await LoanService.applyLoan(req.body.client_id, req.body.amount, req.body.interest_rate, req.body.employee_id);
    res.status(201).json(row);
  } catch (e) { next(e); }
}

async function approve(req, res, next) {
  try { handleValidation(req);
    const row = await LoanService.approveLoan(req.body.loan_id, req.body.employee_id);
    res.json(row);
  } catch (e) { next(e); }
}

async function reject(req, res, next) {
  try { handleValidation(req);
    const row = await LoanService.rejectLoan(req.body.loan_id, req.body.employee_id);
    res.json(row);
  } catch (e) { next(e); }
}

async function markPaid(req, res, next) {
  try { handleValidation(req);
    const row = await LoanService.markLoanPaid(req.body.loan_id);
    res.json(row);
  } catch (e) { next(e); }
}

async function byClient(req, res, next) {
  try {
    const rows = await LoanService.getLoansByClient(Number(req.params.client_id));
    res.json(rows);
  } catch (e) { next(e); }
}

module.exports = { apply, approve, reject, markPaid, byClient };
