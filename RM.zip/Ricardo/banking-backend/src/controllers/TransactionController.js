/**
 * Transaction Controller
 * -----------------------
 * Handles all HTTP endpoints related to money movement in the banking system.
 *
 * Supported Operations:
 *   - Deposit funds into an account
 *   - Withdraw funds from an account
 *   - Transfer money between two accounts
 *   - Pay bills from an account
 *   - Retrieve the full transaction history for a specific account
 *
 * Responsibilities:
 *   - Validate incoming request data (express-validator)
 *   - Call the TransactionService for business logic and database operations
 *   - Return structured JSON results
 *   - Forward errors to global error-handling middleware
 */
const { validationResult } = require('express-validator');
const TxService = require('../services/TransactionService');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function deposit(req, res, next) {
  try { handleValidation(req);
    const out = await TxService.deposit(req.body.account_id, req.body.amount, req.body.employee_id);
    res.json(out);
  } catch (e) { next(e); }
}

async function withdraw(req, res, next) {
  try { handleValidation(req);
    const out = await TxService.withdraw(req.body.account_id, req.body.amount, req.body.employee_id);
    res.json(out);
  } catch (e) { next(e); }
}

async function transfer(req, res, next) {
  try { handleValidation(req);
    const out = await TxService.transfer(req.body.from_account, req.body.to_account, req.body.amount, req.body.employee_id);
    res.json(out);
  } catch (e) { next(e); }
}

async function payBill(req, res, next) {
  try { handleValidation(req);
    const out = await TxService.payBill(req.body.account_id, req.body.amount, req.body.employee_id);
    res.json(out);
  } catch (e) { next(e); }
}

async function history(req, res, next) {
  try {
    const rows = await TxService.getTransactionsByAccount(Number(req.params.account_id));
    res.json(rows);
  } catch (e) { next(e); }
}

module.exports = { deposit, withdraw, transfer, payBill, history };
