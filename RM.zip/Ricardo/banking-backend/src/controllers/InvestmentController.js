/**
 * Investment Controller
 * ----------------------
 * Handles all HTTP endpoints related to client investments.
 *
 * Supported Operations:
 *   - Buy stock (create a new investment entry)
 *   - Sell stock (update investment status from "active" to "sold")
 *   - List all investments belonging to a specific client
 *
 * Responsibilities:
 *   - Validate incoming request data (express-validator)
 *   - Delegate logic to the InvestmentService
 *   - Send structured JSON responses
 *   - Forward errors to the centralized error-handling middleware
 */
const { validationResult } = require('express-validator');
const InvestmentService = require('../services/InvestmentService');

function handleValidation(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new Error('Validation failed');
    err.status = 400;
    err.details = errors.array();
    throw err;
  }
}

async function buy(req, res, next) {
  try { handleValidation(req);
    const row = await InvestmentService.buyStock(req.body.client_id, req.body.stock_symbol, req.body.shares);
    res.status(201).json(row);
  } catch (e) { next(e); }
}

async function sell(req, res, next) {
  try { handleValidation(req);
    const row = await InvestmentService.sellStock(req.body.investment_id);
    res.json(row);
  } catch (e) { next(e); }
}

async function byClient(req, res, next) {
  try {
    const rows = await InvestmentService.getInvestmentsByClient(Number(req.params.client_id));
    res.json(rows);
  } catch (e) { next(e); }
}

module.exports = { buy, sell, byClient };
