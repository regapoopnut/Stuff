/**
 * Authentication & Authorization Middleware
 * ------------------------------------------
 * This file contains:
 *   1. authenticate  → verifies the JWT token in the request
 *   2. authorize(...roles) → ensures the user has the required role(s)
 *
 * These middlewares protect all secure endpoints in the API.
 *
 * Flow:
 *   - User logs in → receives JWT token
 *   - Client sends token in `Authorization: Bearer <token>`
 *   - authenticate verifies token & attaches decoded user to req.user
 *   - authorize checks req.user.role to determine access permissions
 */
const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Unauthenticated' });
    if (!roles.length || roles.includes(req.user.role)) return next();
    return res.status(403).json({ error: 'Forbidden: insufficient role' });
  };
}

module.exports = { authenticate, authorize };
