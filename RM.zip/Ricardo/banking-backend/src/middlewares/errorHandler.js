/**
 * Global Error Handling Middleware
 * ---------------------------------
 * This middleware catches ALL errors thrown in controllers, services,
 * and asynchronous operations (as long as they are passed to next(err)).
 *
 * Express recognizes error-handling middleware by its 4 parameters:
 *   (err, req, res, next)
 *
 * Responsibilities:
 *   - Determine the correct HTTP status code
 *   - Return a clean, consistent JSON error response
 *   - Show stack traces **only in development** (never in production)
 *   - Prevent unhandled crashes by safely catching unexpected errors
 *
 * Error Format Returned to Client:
 *   {
 *     "error": "A description of the error",
 *     "stack": "stack trace here"  
 *   }
 */
function errorHandler(err, req, res, next) {
  const status = err.status || 500;
  const payload = {
    error: err.message || 'Internal Server Error'
  };
  if (process.env.NODE_ENV !== 'production' && err.stack) {
    payload.stack = err.stack;
  }
  res.status(status).json(payload);
}
module.exports = errorHandler;
