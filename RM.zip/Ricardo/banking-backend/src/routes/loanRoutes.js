const express = require('express');
const ctrl = require('../controllers/LoanController');
const { authenticate, authorize } = require('../middlewares/auth');
const { applyLoan, actionLoan } = require('../validators/loanValidators');

const router = express.Router();

router.post('/loans/apply', authenticate, applyLoan, ctrl.apply);
router.post('/loans/approve', authenticate, authorize('manager','admin'), actionLoan, ctrl.approve);
router.post('/loans/reject', authenticate, authorize('manager','admin'), actionLoan, ctrl.reject);
router.post('/loans/mark-paid', authenticate, authorize('manager','admin'), actionLoan, ctrl.markPaid);
router.get('/clients/:client_id/loans', authenticate, ctrl.byClient);

module.exports = router;
