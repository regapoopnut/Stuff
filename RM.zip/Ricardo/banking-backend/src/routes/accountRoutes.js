const express = require('express');
const ctrl = require('../controllers/AccountController');
const tx = require('../controllers/TransactionController');
const { authenticate } = require('../middlewares/auth');
const { createAccount, moveMoney, transfer } = require('../validators/accountValidators');

const router = express.Router();

router.get('/clients/:client_id/accounts', authenticate, ctrl.getByClient);
router.get('/accounts/:id', authenticate, ctrl.getById);
router.post('/accounts', authenticate, createAccount, ctrl.create);
router.delete('/accounts/:account_id', authenticate, ctrl.close);

// transactions
router.get('/accounts/:account_id/transactions', authenticate, tx.history);
router.post('/transactions/deposit', authenticate, moveMoney, tx.deposit);
router.post('/transactions/withdraw', authenticate, moveMoney, tx.withdraw);
router.post('/transactions/transfer', authenticate, transfer, tx.transfer);
router.post('/transactions/pay-bill', authenticate, moveMoney, tx.payBill);

module.exports = router;
