const express = require('express');
const ctrl = require('../controllers/EmployeeController');
const { authenticate, authorize } = require('../middlewares/auth');
const { createEmployee, updateEmployee, login } = require('../validators/employeeValidators');

const router = express.Router();

router.post('/auth/login', login, ctrl.login);

router.get('/employees', authenticate, authorize('admin','manager'), ctrl.list);
router.get('/employees/:id', authenticate, authorize('admin','manager'), ctrl.get);
router.post('/employees', authenticate, authorize('admin'), createEmployee, ctrl.create);
router.put('/employees/:id', authenticate, authorize('admin'), updateEmployee, ctrl.update);
router.delete('/employees/:id', authenticate, authorize('admin'), ctrl.remove);

module.exports = router;
