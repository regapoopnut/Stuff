const express = require('express');
const ctrl = require('../controllers/ClientController');
const { authenticate } = require('../middlewares/auth');
const { createClient, updateClient } = require('../validators/clientValidators');

const router = express.Router();

router.get('/clients', authenticate, ctrl.list);
router.get('/clients/:id', authenticate, ctrl.get);
router.post('/clients', authenticate, createClient, ctrl.create);
router.put('/clients/:id', authenticate, updateClient, ctrl.update);
router.delete('/clients/:id', authenticate, ctrl.remove);

module.exports = router;
