const express = require('express');
const ctrl = require('../controllers/InvestmentController');
const { authenticate } = require('../middlewares/auth');
const { buy, sell } = require('../validators/investmentValidators');

const router = express.Router();

router.get('/clients/:client_id/investments', authenticate, ctrl.byClient);
router.post('/investments/buy', authenticate, buy, ctrl.buy);
router.post('/investments/sell', authenticate, sell, ctrl.sell);

module.exports = router;
