/**
 * Server Entry Point
 * -------------------
 * This file is responsible for:
 *   - Loading environment variables
 *   - Initializing the Express application
 *   - Starting the HTTP server
 *   - Handling graceful shutdown (closing DB connections and server)
 *
 * This is the true "start" of your backend application.
 */

require('dotenv').config();
const app = require('./app');
const { pool } = require('./config/db');

/**
 * Server Startup
 * ----------------
 * Use PORT from environment variables, or fallback to 4000.
 * Starts listening for incoming HTTP requests.
 */
const port = process.env.PORT || 4000;
const server = app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

/**
 * Graceful Shutdown Handling
 * ---------------------------
 * When the process receives a SIGINT signal (Ctrl + C), it:
 *   1. Logs that the server is shutting down
 *   2. Stops accepting new requests (server.close)
 *   3. Closes all PostgreSQL pool connections (pool.end)
 *   4. Exits the process cleanly
 *
 * This prevents:
 *   - Lost database writes
 *   - Half-open database connections
 *   - Corrupted state during shutdown
 */
process.on('SIGINT', async () => {
  console.log('Shutting down...');
  server.close(async () => {
    await pool.end();
    process.exit(0);
  });
});
