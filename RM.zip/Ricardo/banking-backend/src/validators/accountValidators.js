const { body, param } = require('express-validator');

const createAccount = [
  body('client_id').isInt(),
  body('account_type').isIn(['checking','savings','business'])
];

const moveMoney = [
  body('amount').isFloat({ gt: 0 }),
  body('employee_id').isInt()
];

const transfer = [
  body('from_account').isInt(),
  body('to_account').isInt(),
  body('amount').isFloat({ gt: 0 }),
  body('employee_id').isInt()
];

module.exports = { createAccount, moveMoney, transfer };
