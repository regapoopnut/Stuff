const { body, param } = require('express-validator');

const createClient = [
  body('full_name').isString().isLength({ min: 3 }),
  body('email').optional().isEmail().normalizeEmail(),
  body('phone').optional().isString().isLength({ min: 5 }),
  body('address').optional().isString()
];

const updateClient = [
  param('id').isInt(),
  body('full_name').isString().isLength({ min: 3 }),
  body('email').optional().isEmail().normalizeEmail(),
  body('phone').optional().isString().isLength({ min: 5 }),
  body('address').optional().isString()
];

module.exports = { createClient, updateClient };
