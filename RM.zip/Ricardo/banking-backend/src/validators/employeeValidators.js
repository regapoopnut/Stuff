const { body, param } = require('express-validator');

const createEmployee = [
  body('full_name').isString().isLength({ min: 3 }),
  body('branch').optional().isString(),
  body('role').isIn(['admin','manager','teller']),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 })
];

const updateEmployee = [
  param('id').isInt(),
  body('full_name').isString().isLength({ min: 3 }),
  body('branch').optional().isString(),
  body('role').isIn(['admin','manager','teller']),
  body('email').isEmail().normalizeEmail(),
  body('password').optional().isLength({ min: 8 })
];

const login = [
  body('email').isEmail().normalizeEmail(),
  body('password').isString().notEmpty()
];

module.exports = { createEmployee, updateEmployee, login };
