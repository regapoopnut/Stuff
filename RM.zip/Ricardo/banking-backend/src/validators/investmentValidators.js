const { body } = require('express-validator');

const buy = [
  body('client_id').isInt(),
  body('stock_symbol').isString().isLength({ min: 1, max: 10 }).toUpperCase(),
  body('shares').isInt({ gt: 0 })
];

const sell = [
  body('investment_id').isInt()
];

module.exports = { buy, sell };
