const { body } = require('express-validator');

const applyLoan = [
  body('client_id').isInt(),
  body('amount').isFloat({ gt: 0 }),
  body('interest_rate').isFloat({ gte: 0 }),
  body('employee_id').isInt()
];

const actionLoan = [
  body('loan_id').isInt(),
  body('employee_id').optional().isInt()
];

module.exports = { applyLoan, actionLoan };
