/**
 * toAccountDTO(row)
 * ------------------
 * Data Transfer Object (DTO) transformer for account records.
 *
 * Purpose:
 *   Converts a raw database row into a clean, frontend-friendly JSON object.
 *   This ensures that:
 *     - Only safe, allowed fields are exposed to the API response
 *     - Data types (like balance) are formatted correctly
 *     - Null/undefined database results return `null` instead of crashing
 *
 * Why DTOs are useful:
 *   - Prevent leaking sensitive data that may exist in the DB row.
 *   - Enforce consistent API response shapes.
 *   - Decouple internal DB structure from external API structure.
 *
 * Behavior:
 *   - If no row is provided (undefined/null), returns `null`.
 *   - Otherwise returns a sanitized object with selected fields.
 **/
function toAccountDTO(row) {
  if (!row) return null;
  return {
    account_id: row.account_id,
    client_id: row.client_id,
    account_type: row.account_type,
    balance: Number(row.balance),
    created_at: row.created_at
  };
}
module.exports = { toAccountDTO };
