class Transaction {
  constructor({transaction_id, account_id, employee_id, transaction_type, amount, related_account, created_at}) {
    this.transaction_id = transaction_id;
    this.account_id = account_id;
    this.employee_id = employee_id;
    this.transaction_type = transaction_type;
    this.amount = Number(amount);
    this.related_account = related_account;
    this.created_at = created_at;
  }
}
module.exports = Transaction;
