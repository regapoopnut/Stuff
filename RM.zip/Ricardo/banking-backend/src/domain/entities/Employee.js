class Employee {
  constructor({employee_id, full_name, branch, role, email, created_at}) {
    this.employee_id = employee_id;
    this.full_name = full_name;
    this.branch = branch;
    this.role = role;
    this.email = email;
    this.created_at = created_at;
  }
}
module.exports = Employee;
