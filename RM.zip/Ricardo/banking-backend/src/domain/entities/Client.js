class Client {
  constructor({client_id, full_name, email, phone, address, created_at}) {
    this.client_id = client_id;
    this.full_name = full_name;
    this.email = email;
    this.phone = phone;
    this.address = address;
    this.created_at = created_at;
  }
}
module.exports = Client;
