class Investment {
  constructor({investment_id, client_id, stock_symbol, shares, status, created_at}) {
    this.investment_id = investment_id;
    this.client_id = client_id;
    this.stock_symbol = stock_symbol;
    this.shares = shares;
    this.status = status;
    this.created_at = created_at;
  }
}
module.exports = Investment;
