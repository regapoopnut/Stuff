class Account {
  constructor({account_id, client_id, account_type, balance, created_at}) {
    this.account_id = account_id;
    this.client_id = client_id;
    this.account_type = account_type;
    this.balance = Number(balance);
    this.created_at = created_at;
  }
}
module.exports = Account;
