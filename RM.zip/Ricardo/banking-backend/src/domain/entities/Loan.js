class Loan {
  constructor({loan_id, client_id, employee_id, amount, interest_rate, status, created_at}) {
    this.loan_id = loan_id;
    this.client_id = client_id;
    this.employee_id = employee_id;
    this.amount = Number(amount);
    this.interest_rate = Number(interest_rate);
    this.status = status;
    this.created_at = created_at;
  }
}
module.exports = Loan;
