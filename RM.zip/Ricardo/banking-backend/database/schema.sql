/**********************************************************************************************
 * BANKING SYSTEM DATABASE SCHEMA
 * --------------------------------------------------------------------------------------------
 * This schema defines all tables used in the banking backend:
 * Employees, Clients, Accounts, Transactions, Loans, and Investments.
 *
 * It establishes:
 *   - Primary keys
 *   - Foreign key relationships
 *   - Role based constraints
 *   - Data validation via CHECK constraints
 *   - Indexes for performance optimization
 *
 * The system supports:
 *   - Employee authentication and role management
 *   - Client records
 *   - Bank accounts (checking/savings/business)
 *   - Financial transactions and audit trails
 *   - Loan processing workflow
 *   - Investment tracking (stock purchases/sales)
 **********************************************************************************************/

 /**********************************************************************************************
 * EMPLOYEES TABLE
 * --------------------------------------------------------------------------------------------
 * Stores system employees (admins, managers, tellers).
 * Used primarily for:
 *   - Authentication (email + password_hash)
 *   - Role based access control
 *   - Tracking which employee performed a transaction or reviewed a loan
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS employees (
  employee_id   SERIAL PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  branch        VARCHAR(100),
  role          VARCHAR(50)  NOT NULL CHECK (role IN ('admin','manager','teller')),
  email         VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * CLIENTS TABLE
 * --------------------------------------------------------------------------------------------
 * Stores personal information about bank clients.
 * This table is referenced by:
 *   - Accounts
 *   - Loans
 *   - Investments
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS clients (
  client_id   SERIAL PRIMARY KEY,
  full_name   VARCHAR(100) NOT NULL,
  email       VARCHAR(100) UNIQUE,
  phone       VARCHAR(20),
  address     TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * ACCOUNTS TABLE
 * --------------------------------------------------------------------------------------------
 * Represents bank accounts owned by clients.
 * Includes:
 *   - Checking accounts
 *   - Savings accounts
 *   - Business accounts
 *
 * Balance is stored as NUMERIC(14,2) to avoid floating-point rounding errors.
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS accounts (
  account_id   SERIAL PRIMARY KEY,
  client_id    INT NOT NULL REFERENCES clients(client_id) ON DELETE CASCADE,
  account_type VARCHAR(50) NOT NULL CHECK (account_type IN ('checking','savings','business')),
  balance      NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at   TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * TRANSACTIONS TABLE
 * --------------------------------------------------------------------------------------------
 * Records all financial activity:
 *   - Deposits
 *   - Withdrawals
 *   - Transfers (debit/credit)
 *   - Bill payments
 *
 * Stores:
 *   - The employee who executed it
 *   - The related account (for transfers)
 *   - Full audit trail for compliance and logging
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS transactions (
  transaction_id   SERIAL PRIMARY KEY,
  account_id       INT NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
  employee_id      INT REFERENCES employees(employee_id),
  transaction_type VARCHAR(50) NOT NULL CHECK (transaction_type IN ('deposit','withdraw','transfer_debit','transfer_credit','bill_payment')),
  amount           NUMERIC(14,2) NOT NULL CHECK (amount >= 0),
  related_account  INT,
  created_at       TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * LOANS TABLE
 * --------------------------------------------------------------------------------------------
 * Stores loan applications and their lifecycle:
 *   pending to approved to paid
 *   pending to rejected
 *
 * The employee_id refers to the employee who reviewed the loan.
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS loans (
  loan_id       SERIAL PRIMARY KEY,
  client_id     INT NOT NULL REFERENCES clients(client_id) ON DELETE CASCADE,
  employee_id   INT REFERENCES employees(employee_id),
  amount        NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  interest_rate NUMERIC(5,2) NOT NULL CHECK (interest_rate >= 0),
  status        VARCHAR(50) NOT NULL CHECK (status IN ('pending','approved','rejected','paid')),
  created_at    TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * INVESTMENTS TABLE
 * --------------------------------------------------------------------------------------------
 * Tracks stock purchases a client makes through the bank.
 * Includes:
 *   - Number of shares
 *   - Stock ticker symbol
 *   - Investment status (active or sold)
 **********************************************************************************************/
CREATE TABLE IF NOT EXISTS investments (
  investment_id SERIAL PRIMARY KEY,
  client_id     INT NOT NULL REFERENCES clients(client_id) ON DELETE CASCADE,
  stock_symbol  VARCHAR(10) NOT NULL,
  shares        INT NOT NULL CHECK (shares > 0),
  status        VARCHAR(50) NOT NULL CHECK (status IN ('active','sold')),
  created_at    TIMESTAMP DEFAULT NOW()
);

/**********************************************************************************************
 * INDEXES
 * --------------------------------------------------------------------------------------------
 * Improve query performance for common operations such as:
 *   - Fetching accounts by client
 *   - Fetching transactions by account
 *   - Retrieving client loans
 *   - Viewing client investments
 **********************************************************************************************/
CREATE INDEX IF NOT EXISTS idx_accounts_client_id     ON accounts(client_id);
CREATE INDEX IF NOT EXISTS idx_transactions_account   ON transactions(account_id);
CREATE INDEX IF NOT EXISTS idx_loans_client_id        ON loans(client_id);
CREATE INDEX IF NOT EXISTS idx_investments_client_id  ON investments(client_id);
