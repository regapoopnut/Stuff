require('dotenv').config();
const bcrypt = require('bcryptjs');
const { query } = require('../src/config/db');

(async () => {
  try {
    const email = process.env.SEED_ADMIN_EMAIL || 'admin@bank.local';
    const name = process.env.SEED_ADMIN_NAME || 'Admin User';
    const branch = process.env.SEED_ADMIN_BRANCH || 'HQ';
    const role = 'admin';
    const password = process.env.SEED_ADMIN_PASSWORD || 'Admin@123';
    const password_hash = await bcrypt.hash(password, 10);

    const existing = await query('SELECT * FROM employees WHERE email=$1', [email]);
    if (existing.rows[0]) {
      console.log('Admin already exists:', email);
      process.exit(0);
    }

    const { rows } = await query(
      `INSERT INTO employees (full_name, branch, role, email, password_hash)
       VALUES ($1,$2,$3,$4,$5) RETURNING employee_id, email`,
      [name, branch, role, email, password_hash]
    );
    console.log('Seeded admin:', rows[0]);
    process.exit(0);
  } catch (e) {
    console.error('Seed error', e);
    process.exit(1);
  }
})();
