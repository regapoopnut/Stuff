	Setup Instructions:
1)	Extract the zip file and open the “bank backend” folder in visual studio code.
2)	Once you are sure node js works on the system open the terminal and run “npm install”.
3)	Open pgAdmin4 and make sure to create the database given the sql file “schema.sql”.
4)	After that open the terminal in visual studio again and write “npm run seed:admin”.
5)	Then you can run the project by typing “npm run dev” in the terminal.
6)	Once those steps are finished open postman and import the file “Banking Backend API.postman_collection”.
7)	Now login as an admin using the auth endpoint and test the other endpoints provided in the postman collection.

	Roles and their Significance:
	Teller (front line staff), What they can do:
	Look up and update customer profiles.
	Open or close customer accounts.
	Move money for customers: deposits, withdrawals, transfers, bill payments.
	See an account’s transaction history.
	Submit a loan application for a customer.
	Buy or sell basic investments for a customer and view their holdings.
	What they cannot do.
	See or manage the list of bank employees.
	Approve/reject/mark loans as paid. 
	Change anyone’s role or permissions.

	Manager (team lead / branch lead),What they can do:
	Everything a Teller can do.
	See the employee list and view employee details (read only).
	Make loan decisions: approve, reject, or mark a loan as paid.
	What they cannot do
	Create, edit, or delete employee accounts.
	Change employee roles/permissions.

	Admin (system owner), What they can do:
	Everything a Manager can do.
	Create, edit, and delete employee accounts.
	Change employee roles/permissions (make someone a manager).
	What they should avoid (good practice)
	Day to day servicing tasks (deposits, withdrawals, etc.).

	API Endpoints, Usage, and Errors:
	Auth: 
	POST /api/auth/login — Sign in with email/password and receive a JWT token.
	Health:
	GET /health — Quick server status check (returns ok:true).
	Employees (manager read only, admin full CRUD):
	GET /api/employees — List all employees.
	GET /api/employees/:id — Get one employee by ID.
	POST /api/employees — Create a new employee (admin only).
	PUT /api/employees/:id — Update an employee (admin only).
	DELETE /api/employees/:id — Delete an employee (admin only).
	Errors:
o	401: not logged in.
o	403: only admins can create/update/delete; managers can only view.
o	409: duplicate email on create/update.
o	404: employee ID not found.

	Clients:
	GET /api/clients — List all clients.
	GET /api/clients/:id — Get one client by ID.
	POST /api/clients — Create a new client.
	PUT /api/clients/:id — Update a client.
	DELETE /api/clients/:id — Delete a client.
	Errors:
o	400/422: invalid email/phone/name.
o	404: client ID not found.
o	409: duplicate client email (if uniqueness enforced).
	Accounts:
	GET /api/clients/:client_id/accounts — List all accounts for a client.
	GET /api/accounts/:id — Get one account by ID.
	POST /api/accounts — Open a new account for a client.
	DELETE /api/accounts/:account_id — Close an account.
	Errors:
o	400/422: invalid account_type or missing client_id.
o	404: account or client not found.
o	409: closing an already closed account.
	Transactions:
	GET /api/accounts/:account_id/transactions — Get transaction history for an account.
	POST /api/transactions/deposit — Add funds to an account.
	POST /api/transactions/withdraw — Withdraw funds from an account.
	POST /api/transactions/transfer — Transfer funds between two accounts.
	POST /api/transactions/pay-bill — Pay a bill from an account.
	Errors:
o	400/422: amount not positive; same account for from/to; missing IDs.
o	404: account not found.
o	409: insufficient funds; operating on closed account.
o	200/201: success; history shows entries for each movement.
	Loans:
	POST /api/loans/apply — Create a loan application for a client.
	POST /api/loans/approve — Approve a pending loan (manager/admin).
	POST /api/loans/reject — Reject a pending loan (manager/admin).
	POST /api/loans/mark-paid — Mark an approved loan as paid (manager/admin).
	GET /api/clients/:client_id/loans — List all loans for a client.
	Errors:
o	400/422: invalid amount/interest_rate; missing client/employee.
o	403: only manager/admin can approve/reject/mark-paid.
o	404: loan or client not found.
o	409: wrong state transition (approve approved, etc.).
	Investments:
	POST /api/investments/buy — Buy shares for a client.
	POST /api/investments/sell — Sell an existing investment.
	GET /api/clients/:client_id/investments — List a client’s investments.
	Errors:
o	400/422: shares must be > 0; stock symbol required.
o	404: investment or client not found.
o	409: selling an already sold investment.

	Third Party Tools Used:
	JWT (JSON Web Token): is a compact, URL safe string the server gives after you log in. It proves who the user is based on the token generated. It is used for authentication on later requests without keeping a server side session.
	It was used in this project to provide a stateless and scalable security solution without the need for server storage session.

